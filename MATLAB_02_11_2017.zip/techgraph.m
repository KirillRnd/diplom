X = 1.1*max(R(1,:));
Y = 1.1*max(R(2,:));
Z = 1.1*max(R(3,:));
X1 = 1.1*min(R(1,:));
Y1 = 1.1*min(R(2,:));
Z1 = 1.1*min(R(3,:));



%����� �������
E=zeros(iter,3,3);
for i=1:iter
    
    E(i,:,:)=1000000*quatrotate(Q(:,i)',(I'))';
end
for i=2:50:iter
    
    plot3(R(1,1:i-1),R(2,1:i-1),R(3,1:i-1),'r:');
    hold on;
    grid on;
    plot3(R(1,i),R(2,i),R(3,i),'b.');%���� ���� ������� ���
    
    plot3([R(1,i) (R(1,i)+E(i,1,1))],[R(2,i) (R(2,i)+E(i,2,1))],[R(3,i) (R(3,i)+E(i,3,1))],'r');
    plot3([R(1,i) (R(1,i)+E(i,1,2))],[R(2,i) (R(2,i)+E(i,2,2))],[R(3,i) (R(3,i)+E(i,3,2))],'b');
    plot3([R(1,i) (R(1,i)+E(i,1,3))],[R(2,i) (R(2,i)+E(i,2,3))],[R(3,i) (R(3,i)+E(i,3,3))],'y');
    
    plot3(0,0,0,'b--o');
    hold off;
    axis equal;
    str = ['time ' int2str(h*i) ' s'];
    text(10000,100,300,str);
    axis([X1 X Y1 Y Z1 Z]);
    
    pause(0.05)
end